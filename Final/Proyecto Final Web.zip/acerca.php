<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <? require('estilo.php'); ?>
    <title>Nosotros</title>
</head>

<body>
    <? require('navtab.php'); ?>
    <div class="container" style="margin-top:80px">
        <h1 style=" font-family: 'Bangers';">¿Quiénes somos?</h1>

        <p style="font-size: 20px;">En The Comic Book Store nos dedicamos a vender todo tipo de comics, historietas, novelas gráficas. Nos encontramos en la Ciudad de México 
         y contamos con un amplio catalogo que día con día es mayor.</p>
        <p style="font-size: 20px;"> Contamos con distintas editoriales como lo son:
        </p>
        <div class="card-deck">
            <div class="card  border-light mb-3">
                <img class="mx-auto d-block  img-fluid" width="150px" height="75px" src="imagenes/marvel.png" alt="Card image">

            </div>
            <div class="card  border-light mb-3">
                <img class="mx-auto d-block  img-fluid" width="150px" height="75px" src="imagenes/dc.png" alt="Card image">

            </div>
            <div class="card  border-light mb-3">
                <img class="mx-auto d-block img-fluid" width="150px" height="75px" src="imagenes/vertigo.png" alt="Card image">

            </div>
            <div class="card border-light mb-3">
                <img class="mx-auto d-block  img-fluid" width="150px" height="75px" src="imagenes/darkhouse.png" alt="Card image">

            </div>


        </div>
        <p style="font-size: 20px;"> Se realizan envíos a todo el mundo.</p>
        <h1 style=" font-family: 'Bangers';">Contacto</h1>
        <h2>Para más información contactanos por medio de nuestro correo eléctronico que es el siguiente:</h2>
        <p style=" text-align: center;" id="contacto"><a class="btn  btn-outline-info btn-lg" href="mailto:contacto@thecomicbookstore.com"><i class="fas fa-envelope"></i>contacto@thecomicbookstore.com</a></p>






    </div>
</body>

</html>