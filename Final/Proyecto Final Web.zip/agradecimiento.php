<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <?require('estilo.php');?>
    <title>Agradecimiento</title>
</head>
<body>
    <?require('navtab.php');?>
    <div class="container" style="margin-top: 80px;" >
    <h1 style="font-family: 'Bangers';">Gracias por tu compra</h1>
    <h2  style="font-family: 'Bangers';">En breve enviaremos tu pedido a tu dirección</h2>
    </div>
</body>
</html>